package main

import (
	"flag"
	"xoConnecnt/web"
)

func init() {

}

var mode = flag.String("mode", "", "web | CIL")

func main() {
	flag.Parse()
	// slog.Info(*s, "ws", *s)
	if *mode == "web" {
		web.WebRun()
	}
}
