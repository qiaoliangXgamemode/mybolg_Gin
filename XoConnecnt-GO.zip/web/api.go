package web

import (
	"xoConnecnt/web/apis"

	"github.com/gin-gonic/gin"
)

func WebRun() {
	r := gin.Default()
	api := r.Group("/api")
	{
		api.GET("/control/info", apis.GetUserInfo)
		api.GET("/control/controlInfo", apis.GetUserControlInfo)

		api.GET("/control/mappinglist", apis.GetMappingList)

		api.GET("/user/info", func(c *gin.Context) {
			c.JSON(200, gin.H{
				"message": "pong",
			})
		})

		api.GET("/setting/list", func(c *gin.Context) {
			c.JSON(200, gin.H{
				"message": "pong",
			})
		})
	}

	r.Run(":8080")
}
