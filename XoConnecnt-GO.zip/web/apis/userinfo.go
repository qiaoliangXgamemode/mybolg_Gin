package apis

import (
	"io"
	"log"
	"os"

	"github.com/gin-gonic/gin"
)

func GetUserInfo(c *gin.Context) {
	file, err := os.Open("./control/json/user.json")
	if err != nil {
		log.Fatal(err)
	}
	defer file.Close()

	// 读取文件内容
	byteValue, _ := io.ReadAll(file)

	c.JSON(200, string(byteValue))
}

func GetUserControlInfo(c *gin.Context) {
	ss := "[{\"label\":\"状态\",\"value\":\"在线\",\"span\":2},{\"label\":\"节点映射端口数量\",\"value\":\"123\"},{\"label\":\"节点连接数\",\"value\":\"20\"},{\"label\":\"节点总流量统计\",\"value\":\"1.20 Gbps\"},{\"label\":\"节点当前流量\",\"value\":\"1.2 Mbps\"}]"
	c.JSON(200, ss)
}
