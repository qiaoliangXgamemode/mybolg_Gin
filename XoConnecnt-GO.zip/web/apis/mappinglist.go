package apis

import (
	"io"
	"log"
	"os"

	"github.com/gin-gonic/gin"
)

func GetMappingList(c *gin.Context) {
	file, err := os.Open("./control/json/mappinglist.json")
	if err != nil {
		log.Fatal(err)
	}
	defer file.Close()

	// 读取文件内容
	byteValue, _ := io.ReadAll(file)

	c.JSON(200, string(byteValue))
}
