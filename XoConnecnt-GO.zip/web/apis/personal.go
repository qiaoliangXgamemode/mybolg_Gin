package apis

// func GetPersonal(c *gin.Context) {
// 	c.H
// }
